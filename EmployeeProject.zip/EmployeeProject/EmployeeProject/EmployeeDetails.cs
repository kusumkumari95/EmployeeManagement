﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeProject
{
    class EmployeeDetails
    {
        public int empid, deptid, phone, NoOfproject, projid;
        public string empname, empmail, deptname, projname;

        public void employe()
        {
            Console.WriteLine("ENTER THE EMPLOYEE ID:          ");
            empid = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE EMPLOYEE NAME:        ");
            empname = Console.ReadLine();
            Console.WriteLine("ENTER THE EMPLOYEE PHONE:       ");
            phone = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE EMPLOYEE MAILID:      ");
            empmail = Console.ReadLine();
            Console.WriteLine("ENTER THE DEPARTMENT ID:        ");
            deptid = int.Parse(Console.ReadLine());
        }
        public void department()
        {
            Console.WriteLine("ENTER THE DEPARTMENT ID:        ");
            deptid = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE DEPARTMENT NAME:        ");
            deptname = Console.ReadLine();
            Console.WriteLine("ENTER THE NO OF PROJECTS:        ");
            NoOfproject = int.Parse(Console.ReadLine());
        }
        public void projects()
        {
            Console.WriteLine("ENTER THE PROJECT ID:        ");
            projid = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE Department ID:        ");
            deptid = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE PROJECT NAME:        ");
            projname = Console.ReadLine();
            Console.WriteLine("ENTER THE EMPLOYEE  ID:        ");
            empid = int.Parse(Console.ReadLine());
        }
        public string Empoutput()
        {
            return(empid.ToString() + "," + empname + "," + phone.ToString() + "," + empmail + "," + deptid.ToString());
        }
        public string Deptoutput()
        {
            return (deptid.ToString() + "," + deptname + "," + NoOfproject.ToString());
        }
        public string Projoutput()
        {
            return (deptid.ToString() + "," + projid.ToString() + "," + projname + "," + empid.ToString());
        }
    }
}
